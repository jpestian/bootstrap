#!/usr/bin/env bash
set -euo pipefail

###############################################################################
# Pestian Lab Bootstrap
# Usage: source bootstrap.sh
#
# Must be SOURCED (not executed) so conda activate persists in your shell.
# Override the module on OSC if the version changes:
#   MINICONDA_MODULE=miniconda3/24.7.0-py311 source bootstrap.sh
###############################################################################

# ── Source guard ─────────────────────────────────────────────────────────────
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    echo
    echo "  ERROR: This script must be sourced, not executed."
    echo "  Run:   source ${BASH_SOURCE[0]}"
    echo
    exit 1
fi

###############################################################################
# CONFIG  — edit here, or override via environment variables before sourcing
###############################################################################
ENV_NAME="${ENV_NAME:-nlp-core}"
MINICONDA_MODULE="${MINICONDA_MODULE:-miniconda3/24.1.2-py310}"
TORCH_VERSION="${TORCH_VERSION:-2.5.1}"
CUDA_INDEX_URL="${CUDA_INDEX_URL:-https://download.pytorch.org/whl/cu121}"

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$REPO_DIR/config/nlp-core.yml"

###############################################################################
# HEADER
###############################################################################
echo
echo "============================================="
echo " Pestian Lab Bootstrap"
echo "============================================="
echo " Repo    : $REPO_DIR"
echo " Env file: $ENV_FILE"
echo " Env name: $ENV_NAME"
echo "============================================="
echo

###############################################################################
# STEP 1 — Load module (OSC only), then initialize Conda
#          Module must load BEFORE conda info --base is called.
###############################################################################
echo "STEP 1 — Initialize Conda"

if command -v module &>/dev/null; then
    echo "  HPC environment detected — loading $MINICONDA_MODULE"
    module purge
    module load "$MINICONDA_MODULE"
fi

# Now conda is guaranteed to be in PATH (either from module or pre-existing).
CONDA_BASE="$(conda info --base 2>/dev/null)" || {
    echo "  ERROR: 'conda info --base' failed. Is conda in PATH?"
    return 1   # return (not exit) because we are sourced
}

CONDA_SH="$CONDA_BASE/etc/profile.d/conda.sh"
if [[ -f "$CONDA_SH" ]]; then
    # shellcheck source=/dev/null
    source "$CONDA_SH"
else
    echo "  ERROR: Could not find conda.sh at $CONDA_SH"
    return 1
fi

echo "  Conda base: $CONDA_BASE"

###############################################################################
# STEP 2 — Validate repository
###############################################################################
echo
echo "STEP 2 — Validate repository"

if [[ ! -f "$ENV_FILE" ]]; then
    echo "  ERROR: Missing $ENV_FILE"
    return 1
fi
echo "  Found $ENV_FILE"

###############################################################################
# STEP 3 — Create or update the Conda environment
###############################################################################
echo
echo "STEP 3 — Environment setup"

if conda env list | awk '{print $1}' | grep -qx "$ENV_NAME"; then
    echo "  Updating existing environment: $ENV_NAME"
    conda env update -n "$ENV_NAME" -f "$ENV_FILE" --prune
else
    echo "  Creating new environment: $ENV_NAME"
    conda env create -f "$ENV_FILE"
fi

###############################################################################
# STEP 4 — Activate environment
#          conda activate can return non-zero under set -e; guard it.
###############################################################################
echo
echo "STEP 4 — Activate environment"

set +e
conda activate "$ENV_NAME"
ACTIVATE_RC=$?
set -e

if [[ $ACTIVATE_RC -ne 0 ]]; then
    echo "  ERROR: 'conda activate $ENV_NAME' returned $ACTIVATE_RC"
    return 1
fi
echo "  Active env: $(conda info --envs | grep '\*' | awk '{print $1}')"

###############################################################################
# STEP 5 — Install PyTorch (CPU or CUDA build)
#          Torch is intentionally absent from the yml so we can choose the
#          right wheel here rather than installing CPU and reinstalling CUDA.
###############################################################################
echo
echo "STEP 5 — PyTorch installation"

GPU_FOUND=false
if command -v nvidia-smi &>/dev/null && nvidia-smi &>/dev/null 2>&1; then
    GPU_FOUND=true
    CUDA_VER=$(nvidia-smi 2>/dev/null \
        | grep -oP 'CUDA Version: \K[0-9.]+' | head -1 || echo "unknown")
    echo "  GPU detected (driver CUDA $CUDA_VER)"
    echo "  Installing torch==$TORCH_VERSION [CUDA wheel]"
    pip install --quiet \
        "torch==$TORCH_VERSION" \
        --index-url "$CUDA_INDEX_URL"
else
    echo "  No GPU detected"
    echo "  Installing torch==$TORCH_VERSION [CPU wheel]"
    pip install --quiet "torch==$TORCH_VERSION"
fi

###############################################################################
# STEP 6 — Verify
###############################################################################
echo
echo "STEP 6 — Verifying environment"

python - <<'EOF'
import sys

checks = [
    ("numpy",                "numpy"),
    ("pandas",               "pandas"),
    ("scipy",                "scipy"),
    ("scikit-learn",         "sklearn"),
    ("matplotlib",           "matplotlib"),
    ("seaborn",              "seaborn"),
    ("transformers",         "transformers"),
    ("sentence-transformers","sentence_transformers"),
    ("umap-learn",           "umap"),
    ("hdbscan",              "hdbscan"),
    ("torch",                "torch"),
]

failures = []
for label, mod in checks:
    try:
        __import__(mod)
        print(f"  [OK]  {label}")
    except ImportError as e:
        print(f"  [FAIL] {label}: {e}")
        failures.append(label)

import torch
print()
print(f"  Python : {sys.version.split()[0]}")
print(f"  Torch  : {torch.__version__}")
if torch.cuda.is_available():
    print(f"  CUDA   : True")
    print(f"  GPU    : {torch.cuda.get_device_name(0)}")
else:
    print(f"  CUDA   : False (CPU build)")

if failures:
    print()
    print(f"  MISSING PACKAGES: {', '.join(failures)}")
    sys.exit(1)
else:
    print()
    print("  ALL CHECKS PASSED")
EOF

###############################################################################
# DONE
###############################################################################
echo
echo "============================================="
echo " BOOTSTRAP COMPLETE"
echo " Active env : $ENV_NAME"
if [[ "$GPU_FOUND" == true ]]; then
echo " Torch build: CUDA (GPU)"
else
echo " Torch build: CPU"
fi
echo "============================================="
echo
